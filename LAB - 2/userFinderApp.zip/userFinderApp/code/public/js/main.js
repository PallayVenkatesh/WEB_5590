$(document).ready(function(){
	$("#searchUser").on('keyup',function(e){
		let username = e.target.value;


		$.ajax({
			url:'https://api.github.com/users/' + username,
			data: {
				client_id: '3739e09d388d2991aaa9',
				client_secret: '5ad9171c87c6e379297c04a1d6aefade396f674e',
			}
		}).done(function(user){
			$.ajax({
				url:'https://api.github.com/users/' + username + '/repos',
				data: {
				client_id: '3739e09d388d2991aaa9',
				client_secret: '5ad9171c87c6e379297c04a1d6aefade396f674e',
				sort: 'created: asc',
				per_page: 5
			}
			})
			$("#profile").html(`
				<div class="panel panel-default">
					<div class="panel-heading">
						<h3 class="panel-title">${user.name}</h3>
					</div>
					<div class="panel-body">
							<div class = "row">
								<div class = "col-md-3">
									<img class = "thumbnail avatar" src = "${user.avatar_url}">
									<a target = "_blank" class = "btn btn-primary btn-block" href = "${user.html_url}">View Profile</a>

								</div>
								<div class = "col-md-9">
									<span class="label label-default">Public Repos: ${user.public_repos}</span>
									<span class="label label-primary">Public Gists: ${user.public_gists}</span>
									<span class="label label-success">Followers: ${user.followers}</span>
									<span class="label label-info">Following: ${user.following}</span>
									<br><br>
									<ul class="list-group">
										<li class="list-group-item">Company: ${user.company}</li>
										<li class="list-group-item">Location: ${user.location}</li>
										<li class="list-group-item">Website/Blog: <a href= "${user.blog}">${user.blog}</a></li>
										<li class="list-group-item">Member Since: ${user.created_at}</li>
										<li class ="list-group-item">Bio: ${user.bio}</li>
									</ul>
								</div>
							</div>
					</div>
				</div>
				<h3 class = "page-header"> Latest Repos</h3>
				<div id ="repos">

				</div>
			`);

		});
	});
});