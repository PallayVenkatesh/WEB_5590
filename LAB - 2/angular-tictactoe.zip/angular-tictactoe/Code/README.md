tictactoe game with AngularJS

Based on this tutorial: http://www.sitepoint.com/angularjs-tutorial-build-an-app-using-directives-and-data-binding/
