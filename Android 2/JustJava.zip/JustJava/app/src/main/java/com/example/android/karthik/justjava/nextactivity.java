package com.example.android.karthik.justjava;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

/**
 * Created by USER on 10/28/2017.
 */

public class nextactivity extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next);
//        TextView t =(TextView) findViewById(R.id.textView);
//        t.setText(getIntent().getExtras().getString("data"));
    }

}
